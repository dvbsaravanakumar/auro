﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Room_BL.implementation;
using Room_BL.interfaces;
using System.Web.Http.Cors;
using Room_Model;

namespace RoomAPI.Controllers
{
    [EnableCors("http://localhost:21373", "*", "*")]
    public class LoginController : ApiController
    {
        private IUserBL LoginBL;
        public LoginController()
        {
            this.LoginBL = new LoginBL();
        }

        [HttpGet]
        public HttpResponseMessage ValidateUser(string sLoginID, string sPassword)
        {
            //var base64EncodedBytes = System.Convert.FromBase64String(sPassword);
            //var sPassword1 = System.Text.Encoding.UTF8.GetString(base64EncodedBytes);

            //base64EncodedBytes = System.Convert.FromBase64String(sLoginID);
            //var decryptedUserName = System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
            try
            {
                Users userDetails = LoginBL.ValidateUser(sLoginID, sPassword);

                return Request.CreateResponse(HttpStatusCode.OK, userDetails);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }

        [HttpPost]
        public HttpResponseMessage RegisterUser([FromBody]Users usr)
        {            
            try
            {
                Users RegisterDetails = LoginBL.RegisterUser(usr);

                return Request.CreateResponse(HttpStatusCode.OK, RegisterDetails);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }
    }
}
