﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Room_BL.implementation;
using Room_BL.interfaces;
using System.Web.Http.Cors;
using Room_Model;
using log4net;
using log4net.Appender;

namespace RoomAPI.Controllers
{
    [EnableCors("http://localhost:21373", "*", "*")]
    public class MasterController : ApiController
    {
        private readonly ILog log = LogManager.GetLogger("MasterRollingFileAppender");
        private ICountryBL countryBL;
        private IStateBL stateBL;
        private ICityBL cityBL;

        public MasterController()
        {
            log.Debug("Starting method to GetCountryList in API 1");
            this.countryBL = new CountryBL();
            this.stateBL = new StateBL();
            this.cityBL = new CityBL();
        }
 
        [HttpGet]
        public HttpResponseMessage GetCountryList()
        {
            try
            {
                log.Debug("Starting method to GetCountryList in API 2");
               
                var mDetails = countryBL.GetCountryList();
                log.Debug("Processed GetCountryList() - ");

                return Request.CreateResponse(HttpStatusCode.OK, mDetails);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }

        [HttpGet]
        public HttpResponseMessage GetStateListByCountryID(string sCountryID)
        {
            //var base64EncodedBytes = System.Convert.FromBase64String(sCountryID);
            //var CountryID = System.Text.Encoding.UTF8.GetString(base64EncodedBytes);

            try
            {
                //this.stateBL = new StateBL();
                var mDetails = stateBL.GetStateListByCountryID(Convert.ToInt32(sCountryID));

                return Request.CreateResponse(HttpStatusCode.OK, mDetails);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }

        [HttpGet]
        public HttpResponseMessage GetCityListByStateID(string sStateID)
        {
            //var base64EncodedBytes = System.Convert.FromBase64String(sStateID);
            //var StateID = System.Text.Encoding.UTF8.GetString(base64EncodedBytes);

            try
            {
                //this.cityBL = new CityBL();
                var mDetails = cityBL.GetCityListByStateID(Convert.ToInt32(sStateID));

                return Request.CreateResponse(HttpStatusCode.OK, mDetails);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }
    }
}
