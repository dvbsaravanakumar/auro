﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Room_BL.implementation;
using Room_BL.interfaces;
using System.Web.Http.Cors;
using Room_Model;
using log4net;
using log4net.Appender;

namespace RoomAPI.Controllers
{
    [EnableCors("http://localhost:21373", "*", "*")]
    public class RoomController : ApiController
    {
        private readonly ILog log = LogManager.GetLogger("RoomRollingFileAppender");
        private IRoomDetails RoomBL;

        public RoomController()
        {
            log.Debug("Starting method to RoomController in API 1");
            this.RoomBL = new RoomDetailsBL();
        }

        [HttpGet]
        public HttpResponseMessage GetRoomsList(int countryid, int stateid, int cityid, string roomtype, string guesttype)
        {
            try
            {
                log.Debug("Starting method to GetRoomsList in API 2");

                RoomDetails roomdet = new RoomDetails();
                roomdet.COUNTRYID = countryid;
                roomdet.STATEID = stateid;
                roomdet.CITYID = cityid;
                roomdet.ROOMTYPE = roomtype;
                roomdet.GUESTTYPE = guesttype;

                var mRoomDetails = RoomBL.GetRooms(roomdet);
                log.Debug("Processed GetRoomsList() - ");

                return Request.CreateResponse(HttpStatusCode.OK, mRoomDetails);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }
    }
}
