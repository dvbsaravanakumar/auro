﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace RoomAPI
{
    public class ValidationActionFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext context)
        {
            try
            {
                string header = Header(context.Request);
                string storedToken = ConfigurationManager.AppSettings["HeaderToken"].ToString();

                if ((context.ControllerContext.ControllerDescriptor).ControllerName == "UploadFileApi")
                { return; }

                if (header == storedToken)
                    return;
                else
                    context.Response = context.Request.CreateResponse<string>(HttpStatusCode.BadRequest, "Authentication Failed for the user ");
            }
            catch (Exception ex)
            {
                context.Response = context.Request.CreateResponse<string>(HttpStatusCode.BadRequest, "Authentication Failed.  Error occured " + ex.Message);
                return;
            }
        }

        private string Header(HttpRequestMessage request)
        {
            string hUser = string.Empty;
            if (request.Headers.Contains("token"))
            {
                hUser = request.Headers.GetValues("token").FirstOrDefault();
            }
            return hUser;
        }
    }
}