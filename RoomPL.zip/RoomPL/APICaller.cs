﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Http;

/// <summary>
/// Summary description for APICaller
/// </summary>
public class APICaller
{
    private static HttpClient Client { get; set; }

    public APICaller()
    {
        Client = new HttpClient();
        Client.DefaultRequestHeaders.Add("token", "i309asdtkjhw87i692sa");

    }

    public HttpResponseMessage GetResponse(string uri)
    {
        return Client.GetAsync(uri).Result;
    }

    public HttpResponseMessage PostResponse(string uri, HttpContent cont)
    {
        return Client.PostAsync(uri, cont).Result;
    }
}