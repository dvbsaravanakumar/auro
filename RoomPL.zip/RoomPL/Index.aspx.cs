﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Configuration;
using Room_Model;

public partial class Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                loadcountry();

                lbl_UsrName.Text = Session["sesUser"].ToString();

                if (Session["sesUserType"].ToString() == "admin")
                {
                    admin1.Visible = true;
                    admin2.Visible = true;
                    admin3.Visible = true;
                }
                else
                {
                    admin1.Visible = false;
                    admin2.Visible = false;
                    admin3.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            Session.Clear();
            Lbtn_Amin_Logout.Visible = false;
            lbl_UsrName.Text = "Guest";
        }
    }

    protected void Lbtn_Amin_Logout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("Default.aspx");
    }

    private static HttpContent GetContentDataForComplexObject(object data)
    {
        var serializedContent = JsonConvert.SerializeObject(data);
        return new StringContent(serializedContent, Encoding.UTF8, "application/json");
    }

    public void loadcountry()
    {
        ddlCountry.Items.Clear();
        ddlState.Items.Clear();
        ddlCity.Items.Clear();

        string URL = "http://localhost:21373/api/Master/GetCountryList";

        HttpClient Client = new HttpClient();
        Client.DefaultRequestHeaders.Add("token", "i309asdtkjhw87i692sa");

        try
        {
            var apiResponse = Client.GetAsync(URL).Result.Content.ReadAsStringAsync().Result;

            var returnval = JsonConvert.DeserializeObject<List<Country>>(apiResponse);

            if (apiResponse != null)
            {
                ddlCountry.DataSource = returnval;
                ddlCountry.DataBind();
            }

            ddlCountry.Items.Insert(0, new ListItem("-Country-", "-Country-"));
        }
        catch (Exception ex)
        {

        }
    }

    public void loadstate(int countryid)
    {
        ddlState.Items.Clear();
        ddlCity.Items.Clear();

        string URL = "http://localhost:21373/api/Master/GetStateListByCountryID";

        HttpClient Client = new HttpClient();
        Client.DefaultRequestHeaders.Add("token", "i309asdtkjhw87i692sa");

        try
        {
            var apiResponse = Client.GetAsync(URL + "?sCountryID=" + countryid).Result.Content.ReadAsStringAsync().Result;
            var returnval = JsonConvert.DeserializeObject<List<State>>(apiResponse);

            if (apiResponse != null)
            {
                ddlState.DataSource = returnval;
                ddlState.DataBind();
            }


            ddlState.Items.Insert(0, new ListItem("-State-", "-State-"));
        }
        catch (Exception ex)
        {

        }
    }

    public void loadcity(int stateid)
    {
        ddlCity.Items.Clear();

        string URL = "http://localhost:21373/api/Master/GetCityListByStateID";

        HttpClient Client = new HttpClient();
        Client.DefaultRequestHeaders.Add("token", "i309asdtkjhw87i692sa");

        try
        {
            var apiResponse = Client.GetAsync(URL + "?sStateID=" + stateid).Result.Content.ReadAsStringAsync().Result;
            var returnval = JsonConvert.DeserializeObject<List<City>>(apiResponse);

            if (apiResponse != null)
            {
                ddlCity.DataSource = returnval;
                ddlCity.DataBind();
            }

            ddlCity.Items.Insert(0, new ListItem("-City-", "-City-"));
        }
        catch (Exception ex)
        {

        }
    }

    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCountry.SelectedValue.ToString() != "-Country-")
            loadstate(Convert.ToInt32(ddlCountry.SelectedValue.ToString()));
    }

    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlState.SelectedValue.ToString() != "-State-")
            loadcity(Convert.ToInt32(ddlState.SelectedValue.ToString()));
    }

    protected void ddlCity_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void btnFilter_Click(object sender, EventArgs e)
    {
        string URL = "http://localhost:21373/api/Room/GetRoomsList";

        HttpClient Client = new HttpClient();
        Client.DefaultRequestHeaders.Add("token", "i309asdtkjhw87i692sa");

        try
        {
            int countryid; int stateid; int cityid; string roomtype; string guesttype;

            if (ddlCity.SelectedValue.ToString() != "" && ddlCity.SelectedValue.ToString() != "-City-")
                cityid = Convert.ToInt32(ddlCity.SelectedValue.ToString());
            else
                cityid = 0;

            if (ddlState.SelectedValue.ToString() != "" && ddlState.SelectedValue.ToString() != "-State-")
                stateid = Convert.ToInt32(ddlState.SelectedValue.ToString());
            else
                stateid = 0;

            if (ddlCountry.SelectedValue.ToString() != "-Country-")
                countryid = Convert.ToInt32(ddlCountry.SelectedValue.ToString());
            else
                countryid = 0;

            if (ddlRoomType.SelectedValue.ToString() != "-Select-")
                roomtype = ddlRoomType.SelectedValue.ToString();
            else
                roomtype = "0";

            if (ddlGuestType.SelectedValue.ToString() != "-Select-")
                guesttype = ddlGuestType.SelectedValue.ToString();
            else
                guesttype = "0";

            //HttpContent serializedData = GetContentDataForComplexObject(roomdet);
            //var apiResponse = Client.PostAsync(URL, serializedData).Result.Content.ReadAsStringAsync().Result;
            
            var apiResponse = Client.GetAsync(URL + "?countryid=" + countryid + "&stateid=" + stateid + "&cityid=" + cityid + "&roomtype=" + roomtype + "&guesttype=" + guesttype).Result.Content.ReadAsStringAsync().Result;
            var returnval = JsonConvert.DeserializeObject<List<RoomDetails>>(apiResponse);

            if (apiResponse != null)
            {
                RepeatRoomDetails.DataSource = returnval;
                RepeatRoomDetails.DataBind();
            }
            else
            {
                lblMsg.Text = "No Records Found!.";
            }
        }
        catch (Exception ex)
        {

        }
    }
}