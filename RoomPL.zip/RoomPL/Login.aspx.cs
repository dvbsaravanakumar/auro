﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Configuration;
using Room_Model;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Session.Clear();
            Lbtn_Amin_Logout.Visible = false;
            lbl_UsrName.Text = "Guest";
        }
        catch (Exception ex)
        {
            Session.Clear();
            Lbtn_Amin_Logout.Visible = false;
            lbl_UsrName.Text = "Guest";
        }
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        string URL = "http://localhost:21373/api/LoginController/RegisterUser";
        //string updateJobsURL = ConfigurationManager.AppSettings["UpdateJobsURL"].ToString();
        //string apiResponse = "";

        HttpClient Client = new HttpClient();
        Client.DefaultRequestHeaders.Add("token", "i309asdtkjhw87i692sa");

        try
        {
            Users usr = new Users();
            usr.FirstName = txtFirstName.Text;
            usr.LastName = txtLastName.Text;
            usr.MailId = txtEmailID.Text;
            usr.Password = txtPassword.Text;

            HttpContent serializedData = GetContentDataForComplexObject(usr);
            var apiResponse = Client.PutAsync(URL, serializedData).Result.Content.ReadAsStringAsync().Result;

            //var apiResponse = repo.GetResponse(Getaddress).Content.ReadAsStringAsync().Result;

            if (apiResponse != null)
            {
                lblLgnError.Text = "Registered Successfully!";
            }
            else
            {
                lblLgnError.Text = "Error!. Try again.";
            }
        }
        catch (Exception ex)
        {
            lblLgnError.Text = "Error!. Try again.";

        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string URL = "http://localhost:21373/api/Login/ValidateUser";

        HttpClient Client = new HttpClient();
        Client.DefaultRequestHeaders.Add("token", "i309asdtkjhw87i692sa");

        try
        {
            var apiResponse = Client.GetAsync(URL + "?sLoginID=" + txtLgnEmailID.Text + "&sPassword=" + txtLgnPassword.Text).Result.Content.ReadAsStringAsync().Result;
            var returnval = JsonConvert.DeserializeObject<List<Users>>(apiResponse);

            if (apiResponse != null)
            {
                foreach (var list in returnval)
                {
                    Session["sesUser"] = list.ID.ToString();
                    Session["sesUserType"] = list.Role.ToString();
                }

                Response.Redirect("Index.aspx");
            }
            else
            {
                lblLgnError.Text = "Error!. Try again.";
                Session.Clear();
            }


        }
        catch (Exception ex)
        {
            lblLgnError.Text = "Error while updating entries in DB";
        }
    }

    protected void Lbtn_Amin_Logout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("Default.aspx");
    }

    private static HttpContent GetContentDataForComplexObject(object data)
    {
        var serializedContent = JsonConvert.SerializeObject(data);
        return new StringContent(serializedContent, Encoding.UTF8, "application/json");
    }


}