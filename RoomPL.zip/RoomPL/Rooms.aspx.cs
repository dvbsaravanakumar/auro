﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Rooms : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                //lbl_UsrName.Text = Session["sesUser"].ToString();

                //if (Session["sesUserType"].ToString() == "admin")
                //{
                //    admin1.Visible = true;
                //    admin2.Visible = true;
                //    admin3.Visible = true;
                //}
                //else
                //{
                //    admin1.Visible = false;
                //    admin2.Visible = false;
                //    admin3.Visible = false;
                //}
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("Default.aspx");
        }
    }

    protected void Lbtn_Amin_Logout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("Default.aspx");
    }
}