﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Room_Model;
using Room_BL.interfaces;
using System.Data;
using Room_DAL;
using Room_DAL.implementation;
using Room_DAL.interfaces;

namespace Room_BL.implementation
{
    public class CityBL : ICityBL
    {
        private ICityRepository cityRepository;

        public CityBL()
        {
            this.cityRepository = new CityRepository();
        }

        public List<City> GetCityListByStateID(int stateid)
        {
            List<City> mmodel = new List<City>();
            try
            {
                DataTable objLVDataTable;
                string StrsqlQuery = "SELECT CITYID, CITYNAME FROM tblCity WHERE STATEID = '" + stateid + "' ORDER BY CITYNAME";

                objLVDataTable = cityRepository.GetCityList(StrsqlQuery);

                if (objLVDataTable.Rows.Count != 0)
                {
                    foreach (DataRow drow in objLVDataTable.Rows)
                    {
                        City objmaster = new City();
                        objmaster.CityID = Convert.ToInt32(drow.ItemArray[0].ToString());
                        objmaster.CityName = drow.ItemArray[1].ToString();

                        mmodel.Add(objmaster);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return mmodel;
        }
    }
}