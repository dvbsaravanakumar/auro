﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Room_Model;
using Room_BL.interfaces;
using System.Data;
using Room_DAL;
using Room_DAL.implementation;
using Room_DAL.interfaces;

namespace Room_BL.implementation
{
    public class CountryBL : ICountryBL
    {
        private ICountryRepository countryRepository;

        public CountryBL()
        {
            this.countryRepository = new CountryRepository();
        }

        public List<Country> GetCountryList()
        {
            List <Country> mmodel = new List<Country>();
            try
            {
                DataTable objLVDataTable;
                string StrsqlQuery = "SELECT COUNTRYID, COUNTRYNAME FROM tblCountry ORDER BY COUNTRYNAME";

                objLVDataTable = countryRepository.GetCountryList(StrsqlQuery);

                if (objLVDataTable.Rows.Count != 0)
                {
                    foreach (DataRow drow in objLVDataTable.Rows)
                    {
                        Country objMaster = new Country();
                        objMaster.CountryID = Convert.ToInt32(drow.ItemArray[0].ToString());
                        objMaster.CountryName = drow.ItemArray[1].ToString();

                        mmodel.Add(objMaster);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return mmodel;
        }
    }
}
