﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Room_Model;
using Room_BL.interfaces;
using System.Data;
using Room_DAL;
using Room_DAL.implementation;
using Room_DAL.interfaces;

namespace Room_BL.implementation
{
    public class LoginBL : IUserBL
    {
        private ILoginRepository loginRepository;
        public LoginBL()
        {
            this.loginRepository = new LoginRepository();
        }

        public Users ValidateUser(string sMailid, string sPassword)
        {
            Users usermodel = new Users();
            try
            {
                DataTable objLVDataTable;
                string StrsqlQuery = "SELECT ID, FIRSTNAME, LASTNAME, EMAILID, SEX, DOB, ROLE FROM tblUsers WHERE EMAILID = '" + sMailid + "' and PASSWORD = = '" + sPassword + "'";

                objLVDataTable = loginRepository.ValidateUser(StrsqlQuery);

                if (objLVDataTable.Rows.Count != 0)
                {
                    foreach (DataRow drow in objLVDataTable.Rows)
                    {
                        usermodel.ID = drow.ItemArray[0].ToString();
                        usermodel.FirstName = drow.ItemArray[1].ToString();
                        usermodel.LastName = drow.ItemArray[2].ToString();
                        usermodel.MailId = drow.ItemArray[3].ToString();
                        usermodel.Sex = drow.ItemArray[4].ToString();
                        usermodel.DOB = Convert.ToDateTime(drow.ItemArray[5].ToString());
                        usermodel.Role = drow.ItemArray[6].ToString();
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return usermodel;
        }

        public Users RegisterUser(Users usr)
        {
            string returnval = "";
            Users usermodel = new Users();
            try
            {
                string StrsqlQuery = "INSERT INTO tblUsers (FIRSTNAME, LASTNAME, EMAILID, CREATEDDT, ROLE) VALUES ('" + usr.FirstName + "', '" + usr.FirstName + "', '" + usr.MailId + "', '" + DateTime.UtcNow + "', 'USER')";

                returnval = loginRepository.RegisterUser(StrsqlQuery);

                if (returnval != "")
                {
                    usermodel.FirstName = usr.FirstName;
                    usermodel.LastName = usr.LastName;
                    usermodel.MailId = usr.MailId;
                }
            }
            catch (Exception ex)
            {

            }
            return usermodel;
        }
    }
}
