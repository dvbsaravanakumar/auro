﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Room_Model;
using Room_BL.interfaces;
using System.Data;
using Room_DAL;
using Room_DAL.implementation;
using Room_DAL.interfaces;

namespace Room_BL.implementation
{
    public class RoomDetailsBL : IRoomDetails
    {
        private IRoomDetailsRepository roomdetailsRepository;

        public RoomDetailsBL()
        {
            this.roomdetailsRepository = new RoomDetailsRepository();
        }

        public List<RoomDetails> GetRooms(RoomDetails roomdet)
        {
            List<RoomDetails> lstRoomModel = new List<RoomDetails>();
            try
            {
                DataTable objLVDataTable;

                string StrsqlQuery = "prGetRooms";

                objLVDataTable = roomdetailsRepository.GetRoomDetails(StrsqlQuery, roomdet);

                if (objLVDataTable.Rows.Count != 0)
                {
                    foreach (DataRow drow in objLVDataTable.Rows)
                    {
                        RoomDetails objRooms = new RoomDetails();
                        //objRooms.ID = drow.ItemArray[0].ToString();
                        //objRooms.FirstName = drow.ItemArray[1].ToString();
                        //objRooms.LastName = drow.ItemArray[2].ToString();
                        //objRooms.MailId = drow.ItemArray[3].ToString();
                        //objRooms.Sex = drow.ItemArray[4].ToString();
                        //objRooms.DOB = Convert.ToDateTime(drow.ItemArray[5].ToString());
                        //objRooms.Role = drow.ItemArray[6].ToString();

                        lstRoomModel.Add(objRooms);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return lstRoomModel;
        }
    }
}
