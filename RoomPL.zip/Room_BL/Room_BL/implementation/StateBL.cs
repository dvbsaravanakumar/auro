﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Room_Model;
using Room_BL.interfaces;
using System.Data;
using Room_DAL;
using Room_DAL.implementation;
using Room_DAL.interfaces;

namespace Room_BL.implementation
{
    public class StateBL : IStateBL
    {
        private IStateRepository stateRepository;

        public StateBL()
        {
            this.stateRepository = new StateRepository();
        }

        public List<State> GetStateListByCountryID(int countryid)
        {
            List<State> mmodel = new List<State>();
            try
            {
                DataTable objLVDataTable;
                string StrsqlQuery = "SELECT STATEID, STATENAME FROM tblState WHERE COUNTRYID = '" + countryid + "' ORDER BY STATENAME";

                objLVDataTable = stateRepository.GetStateList(StrsqlQuery);

                if (objLVDataTable.Rows.Count != 0)
                {
                    foreach (DataRow drow in objLVDataTable.Rows)
                    {
                        State objmaster = new State();
                        objmaster.StateID = Convert.ToInt32(drow.ItemArray[0].ToString());
                        objmaster.StateName = drow.ItemArray[1].ToString();

                        mmodel.Add(objmaster);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return mmodel;
        }
    }
}
