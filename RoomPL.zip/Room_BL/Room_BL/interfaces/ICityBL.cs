﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Room_Model;

namespace Room_BL.interfaces
{
    public interface ICityBL
    {
        List<City> GetCityListByStateID(int StateID);
    }
}
