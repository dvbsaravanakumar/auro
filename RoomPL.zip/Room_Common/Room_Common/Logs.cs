﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;

namespace Room_Common
{
    public static class Logs
    {
        public static void LogErrorToFile(Exception ex, string details = "")
        {
            try
            {
                string message = "--------------ROOM Mgmt--------------";
                message += Environment.NewLine;
                message += Environment.NewLine;
                message += "Executed on:";
                message += string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
                message += Environment.NewLine;
                message += "-----------------------------------------------------------";
                message += Environment.NewLine;
                message += Environment.NewLine;
                message += "ERROR MESSAGE: " + ex.Message;
                message += Environment.NewLine;
                message += "DATA: " + ex.Data;
                message += Environment.NewLine;
                message += "INNER EXCEPTION: " + ex.InnerException;
                message += Environment.NewLine;
                message += "SOURCE: " + ex.Source;
                message += Environment.NewLine;
                message += "STACK TRACE: " + ex.StackTrace;
                message += Environment.NewLine;
                message += "TARGET SITE: " + ex.TargetSite;
                message += Environment.NewLine;
                message += "HRESULT: " + ex.HResult;
                message += Environment.NewLine;
                message += "HELP LINK: " + ex.HelpLink;
                message += Environment.NewLine;
                message += Environment.NewLine;

                string path = ConfigurationManager.AppSettings["LogLocation"];
                using (StreamWriter writer = new StreamWriter(path, true))
                {
                    writer.WriteLine(message);
                    writer.WriteLine(details);
                    writer.Close();
                }
            }
            catch (Exception e)
            {

            }

        }
    }
}
