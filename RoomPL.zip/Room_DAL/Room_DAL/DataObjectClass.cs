﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Room_DAL
{
    public class DataObjectClass
    {
        string strCon;
        SqlConnection objCon;
        string strErrorMessage;
        int intRowsAffected = 0;

        public DataObjectClass()
        {
            strCon = ConfigurationManager.ConnectionStrings["RoomDB"].ToString();
            objCon = new SqlConnection(strCon);
        }

        private SqlCommand BuildQueryCommandWithSQL(string SQLString)
        {
            SqlCommand objCmd = new SqlCommand(SQLString, objCon);
            objCmd.CommandType = CommandType.Text;
            return objCmd;
        }
        
        public string SQLScalarCommand(string query)
        {
            string result = "";
            objCon.Open();

            SqlCommand command = new SqlCommand(query, objCon);
            var resultFromdb = command.ExecuteScalar();
            if (resultFromdb != null)
            {
                result = resultFromdb.ToString();
            }

            if (!(objCon == null))
            {
                objCon.Close();
                objCon.Dispose();
                objCon = null;
            }
            return result;

        }
        public DataTable getSQLDataTable(string SQLString)
        {
            intRowsAffected = 0;
            strErrorMessage = "";
            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDA = new SqlDataAdapter();
            
            objCon.Open();
            sqlDA.SelectCommand = BuildQueryCommandWithSQL(SQLString);

            sqlDA.Fill(dataTable);

            if (!(objCon == null))
            {
                objCon.Close();
                objCon.Dispose();
                objCon = null;
            }

            sqlDA.Dispose();
            sqlDA = null;

            return dataTable;

        }

        public DataTable getSQLDataTablePR(string SQLString, Room_Model.RoomDetails roomdet)
        {
            intRowsAffected = 0;
            strErrorMessage = "";
            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDA = new SqlDataAdapter();

            objCon.Open();

            SqlCommand objCmd = new SqlCommand(SQLString, objCon);
            objCmd.CommandType = CommandType.StoredProcedure;
            sqlDA.SelectCommand = objCmd;
            objCmd.Parameters.Add("@CountryID", SqlDbType.NVarChar).Value = roomdet.COUNTRYID;
            objCmd.Parameters.Add("@StateID", SqlDbType.NVarChar).Value = roomdet.STATEID;
            objCmd.Parameters.Add("@CityID", SqlDbType.NVarChar).Value = roomdet.CITYID;
            objCmd.Parameters.Add("@RoomType", SqlDbType.NVarChar).Value = roomdet.ROOMTYPE;
            objCmd.Parameters.Add("@GuestType", SqlDbType.NVarChar).Value = roomdet.GUESTTYPE;

            sqlDA.Fill(dataTable);

            if (!(objCon == null))
            {
                objCon.Close();
                objCon.Dispose();
                objCon = null;
            }

            sqlDA.Dispose();
            objCmd.Dispose();
            sqlDA = null;
            objCmd = null;
            return dataTable;

        }
    }
}
