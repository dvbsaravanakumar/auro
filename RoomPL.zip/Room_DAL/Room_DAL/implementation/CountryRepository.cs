﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Room_DAL.interfaces;
using System.Data;

namespace Room_DAL.implementation
{
    public class CountryRepository : ICountryRepository
    {
        DataObjectClass objCVDataObjectClass = new DataObjectClass();

        public DataTable GetCountryList(string qry)
        {
            DataTable objLVDataTable = new DataTable();
            objLVDataTable = objCVDataObjectClass.getSQLDataTable(qry);
            return objLVDataTable;
        }
    }
}
