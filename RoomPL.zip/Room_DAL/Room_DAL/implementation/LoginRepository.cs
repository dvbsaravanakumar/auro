﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Room_DAL.interfaces;
using System.Data;

namespace Room_DAL.implementation
{
    public class LoginRepository : ILoginRepository
    {
        DataObjectClass objCVDataObjectClass = new DataObjectClass();

        public LoginRepository()
        {

        }

        public DataTable ValidateUser(string qry)
        {
            DataTable objLVDataTable = new DataTable();
            objLVDataTable = objCVDataObjectClass.getSQLDataTable(qry);
            return objLVDataTable;
        }

        public String RegisterUser(string qry)
        {
            string returnval = "";
            returnval = objCVDataObjectClass.SQLScalarCommand(qry);
            return returnval;
        }
    }
}
