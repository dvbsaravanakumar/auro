﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Room_DAL.interfaces;
using System.Data;

namespace Room_DAL.implementation
{
    public class RoomDetailsRepository : IRoomDetailsRepository
    {
        DataObjectClass objCVDataObjectClass = new DataObjectClass();

        public RoomDetailsRepository()
        {

        }

        public DataTable GetRoomDetails(string qry, Room_Model.RoomDetails roomdet)
        {
            DataTable objLVDataTable = new DataTable();
            objLVDataTable = objCVDataObjectClass.getSQLDataTablePR(qry, roomdet);
            return objLVDataTable;
        }
    }
}
