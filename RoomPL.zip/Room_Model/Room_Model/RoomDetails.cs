﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Room_Model
{
    public class RoomDetails
    {
        public int ROOMID { get; set; }
        public int ROOMNUMBER { get; set; }
        public int ROOMTYPEID { get; set; }
        public string ADDRESS1 { get; set; }
        public string ADDRESS2 { get; set; }
        public int CITYID { get; set; }
        public int STATEID { get; set; }
        public int COUNTRYID { get; set; }

        public int CITYNAME { get; set; }
        public int STATENAME { get; set; }
        public int COUNTRYNAME { get; set; }
        public string AMENITIES { get; set; }
        public string STATUS { get; set; }
        public string ROOMTYPE { get; set; }
        public string GUESTTYPE { get; set; }
        public int MALEALLOWED { get; set; }
        public int FEMALEALLOWED { get; set; }
        public int BOTH { get; set; }
        public int GUESTALLOWED { get; set; }
    }
}
