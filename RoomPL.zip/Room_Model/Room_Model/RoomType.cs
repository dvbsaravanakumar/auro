﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Room_Model
{
    public class RoomType
    {
        public int TYPEID { get; set; }
        public string ROOMTYPE { get; set; }
        public string GUESTTYPE { get; set; }
        public int MALEALLOWED { get; set; }
        public int FEMALEALLOWED { get; set; }
        public int BOTH { get; set; }
        public int GUESTALLOWED { get; set; }
    }
}
