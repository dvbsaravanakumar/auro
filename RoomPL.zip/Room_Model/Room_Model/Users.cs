﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Room_Model
{
    public class Users
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int UserID { get; set; }
        public string LogonId { get; set; }
        public DateTime DOB { get; set; }
        public string Sex { get; set; }
        public string ID { get; set; }
        public string Status { get; set; }
        public string Category { get; set; }
        public List<string> UsersList { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string MailId { get; set; }
        public string Role { get; set; }
    }
}
